The input instruction is on input-instructions.txt and the configuration of system is on configuration.txt. The output result is on output.txt. 

For running the simulator:
Make
./tomasulo-simulator